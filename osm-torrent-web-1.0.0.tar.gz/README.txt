OSM Torrent Demo - Webserver Drop-in Package
=============================================

Version: 1.0.0
Size: ~100KB
License: ODbL 1.0

CONTENTS
--------
www/          - Website files (HTML, CSS, JS)
nginx/        - Nginx configuration
apache/       - Apache configuration  
docs/         - Installation guide

QUICK INSTALL
-------------
1. Extract: tar -xzf osm-torrent-web-1.0.0.tar.gz
2. Copy www/ to your webserver root
3. Add nginx or apache config
4. Reload webserver
5. Access in browser

See docs/INSTALL.md for detailed instructions.

FEATURES
--------
✅ Pure static HTML (no backend)
✅ Interactive Leaflet map
✅ 22 doors from 71 Doors Gallery
✅ Torrent piece demo (99.995% reduction)
✅ Works with any webserver

SUPPORT
-------
GitHub: meta-introspector/osm-planet-torrent
