# OSM Torrent Demo - Installation Guide

## Quick Start

### Nginx

1. Copy files:
   ```bash
   sudo cp -r www/* /var/www/osm-torrent/
   sudo cp nginx/osm-torrent.conf /etc/nginx/conf.d/
   ```

2. Test and reload:
   ```bash
   sudo nginx -t
   sudo systemctl reload nginx
   ```

3. Access: http://your-server/osm-torrent/

### Apache

1. Copy files:
   ```bash
   sudo cp -r www/* /var/www/osm-torrent/
   sudo cp apache/osm-torrent.conf /etc/apache2/conf-available/
   ```

2. Enable and reload:
   ```bash
   sudo a2enconf osm-torrent
   sudo systemctl reload apache2
   ```

3. Access: http://your-server/osm-torrent/

### User Directory (Nginx)

1. Copy to home:
   ```bash
   mkdir -p ~/public_html/osm-torrent
   cp -r www/* ~/public_html/osm-torrent/
   ```

2. Add to nginx config:
   ```nginx
   location /~username/osm-torrent/ {
       alias /home/username/public_html/osm-torrent/;
   }
   ```

### User Directory (Apache)

1. Copy to home:
   ```bash
   mkdir -p ~/public_html/osm-torrent
   cp -r www/* ~/public_html/osm-torrent/
   ```

2. Enable userdir:
   ```bash
   sudo a2enmod userdir
   sudo systemctl reload apache2
   ```

3. Access: http://your-server/~username/osm-torrent/

## What's Included

- **Interactive Leaflet map** showing Kumbakonam (piece 13668)
- **22 doors** from 71 Doors Gallery
- **Maps viewer** with OSM integration
- **Torrents page** with download links

## Features

- 🧲 Torrent piece 13668 (4MB from 86GB planet)
- 📍 Kumbakonam location (Ramanujan's birthplace)
- 🗺️ Interactive Leaflet map
- 📊 99.995% data reduction
- 🚪 22 interactive doors

## Requirements

- Web server (Nginx or Apache)
- No backend needed (pure static HTML)
- Network access for OSM tiles (at runtime)

## Customization

Edit `www/index.html` to change:
- Map center coordinates
- Zoom level
- Marker text
- Info panel content

## Support

- GitHub: https://github.com/meta-introspector/osm-planet-torrent
- Docs: https://meta-introspector.github.io/osm-planet-71-doors/
